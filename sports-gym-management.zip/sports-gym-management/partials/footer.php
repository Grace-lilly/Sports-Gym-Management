<footer class="bg-dark text-light py-4 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h5>Sports Gym Management</h5>
                <p>Your premier destination for sports and fitness excellence.</p>
            </div>
            <div class="col-md-6 text-md-end">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="/sports-gym-management/pages/contact.php" class="text-light">Contact Us</a></li>
                    <li><a href="/sports-gym-management/pages/about.php" class="text-light">About Us</a></li>
                    <li><a href="/sports-gym-management/pages/terms.php" class="text-light">Terms of Service</a></li>
                </ul>
            </div>
        </div>
        <hr class="bg-light">
        <div class="text-center">
            <p class="mb-0">&copy; <?php echo date('Y'); ?> Sports Gym Management. All rights reserved.</p>
        </div>
    </div>
</footer>

<!-- Custom JS -->
<script src="/sports-gym-management/js/script.js"></script>
</body>
</html> 