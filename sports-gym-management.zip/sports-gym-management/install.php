<?php
// Check if already installed
if (file_exists('config/installed.lock')) {
    die('The system is already installed. Please remove config/installed.lock to reinstall.');
}

// Function to test database connection
function testConnection($host, $username, $password) {
    try {
        $pdo = new PDO("mysql:host=$host", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

// Function to create database
function createDatabase($host, $username, $password, $dbname) {
    try {
        $pdo = new PDO("mysql:host=$host", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname`");
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

// Function to import SQL file
function importSQL($host, $username, $password, $dbname, $sqlFile) {
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $sql = file_get_contents($sqlFile);
        $pdo->exec($sql);
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = $_POST['host'] ?? 'localhost';
    $username = $_POST['username'] ?? 'root';
    $password = $_POST['password'] ?? '';
    $dbname = $_POST['dbname'] ?? 'sports_gym_db';
    
    $success = true;
    $message = '';
    
    // Test connection
    if (!testConnection($host, $username, $password)) {
        $success = false;
        $message .= "Database connection failed. Please check your credentials.<br>";
    }
    
    // Create database
    if ($success && !createDatabase($host, $username, $password, $dbname)) {
        $success = false;
        $message .= "Failed to create database.<br>";
    }
    
    // Import SQL
    if ($success && !importSQL($host, $username, $password, $dbname, 'database/sports_gym_db.sql')) {
        $success = false;
        $message .= "Failed to import database structure.<br>";
    }
    
    // Update config file
    if ($success) {
        $config = "<?php
// Database configuration
\$host = '$host';
\$dbname = '$dbname';
\$username = '$username';
\$password = '$password';

try {
    \$pdo = new PDO(
        \"mysql:host=\$host;dbname=\$dbname;charset=utf8mb4\",
        \$username,
        \$password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException \$e) {
    error_log(\"Database Connection Error: \" . \$e->getMessage());
    die(\"Sorry, there was a problem connecting to the database.\");
}";
        
        if (file_put_contents('config/db_connect.php', $config)) {
            // Create lock file
            file_put_contents('config/installed.lock', date('Y-m-d H:i:s'));
            $message = "Installation completed successfully! You can now <a href='index.php'>access the system</a>.";
        } else {
            $success = false;
            $message .= "Failed to update configuration file.<br>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install Sports Gym Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Install Sports Gym Management System</h4>
                    </div>
                    <div class="card-body">
                        <?php if (isset($message)): ?>
                            <div class="alert <?php echo $success ? 'alert-success' : 'alert-danger'; ?>">
                                <?php echo $message; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="post" action="">
                            <div class="mb-3">
                                <label for="host" class="form-label">Database Host</label>
                                <input type="text" class="form-control" id="host" name="host" value="localhost" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="username" class="form-label">Database Username</label>
                                <input type="text" class="form-control" id="username" name="username" value="root" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">Database Password</label>
                                <input type="password" class="form-control" id="password" name="password">
                            </div>
                            
                            <div class="mb-3">
                                <label for="dbname" class="form-label">Database Name</label>
                                <input type="text" class="form-control" id="dbname" name="dbname" value="sports_gym_db" required>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100">Install</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 