<?php
require_once 'config/db_connect.php';

$tests = [];
$all_passed = true;

function runTest($name, $test) {
    global $tests, $all_passed;
    try {
        $result = $test();
        $tests[] = [
            'name' => $name,
            'status' => $result ? 'PASS' : 'FAIL',
            'message' => $result ? 'Test passed successfully' : 'Test failed'
        ];
        if (!$result) $all_passed = false;
    } catch (Exception $e) {
        $tests[] = [
            'name' => $name,
            'status' => 'ERROR',
            'message' => $e->getMessage()
        ];
        $all_passed = false;
    }
}

// Test database connection
runTest('Database Connection', function() use ($pdo) {
    return $pdo->query('SELECT 1')->fetch() !== false;
});

// Test tables existence
$required_tables = ['users', 'equipment', 'events', 'achievements', 'sessions', 
                   'session_bookings', 'registrations', 'updates'];
foreach ($required_tables as $table) {
    runTest("Table '$table' exists", function() use ($pdo, $table) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        return $stmt->rowCount() > 0;
    });
}

// Test admin user creation
runTest('Admin User Creation', function() use ($pdo) {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
    $stmt->execute();
    return $stmt->rowCount() > 0;
});

// Test session functionality
runTest('Session Management', function() use ($pdo) {
    session_start();
    return isset($_SESSION);
});

// Display Results
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Test Results</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container py-5">
        <h1 class="mb-4">System Test Results</h1>
        
        <div class="alert <?php echo $all_passed ? 'alert-success' : 'alert-warning'; ?>">
            <strong>Overall Status:</strong> 
            <?php echo $all_passed ? 'All tests passed!' : 'Some tests failed'; ?>
        </div>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Test</th>
                        <th>Status</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tests as $test): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($test['name']); ?></td>
                            <td>
                                <span class="badge bg-<?php 
                                    echo $test['status'] === 'PASS' ? 'success' : 
                                         ($test['status'] === 'FAIL' ? 'danger' : 'warning'); 
                                ?>">
                                    <?php echo htmlspecialchars($test['status']); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($test['message']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            <h3>XAMPP Configuration Checklist:</h3>
            <ul class="list-group">
                <li class="list-group-item">
                    <i class="fas fa-check text-success"></i> 
                    PHP Version: <?php echo phpversion(); ?>
                </li>
                <li class="list-group-item">
                    <i class="fas fa-check text-success"></i> 
                    PDO MySQL Extension: <?php echo extension_loaded('pdo_mysql') ? 'Enabled' : 'Disabled'; ?>
                </li>
                <li class="list-group-item">
                    <i class="fas fa-check text-success"></i> 
                    MySQL Server: <?php echo $pdo->getAttribute(PDO::ATTR_SERVER_VERSION); ?>
                </li>
                <li class="list-group-item">
                    <i class="fas fa-check text-success"></i> 
                    Document Root: <?php echo $_SERVER['DOCUMENT_ROOT']; ?>
                </li>
            </ul>
        </div>

        <div class="mt-4">
            <h3>Next Steps:</h3>
            <ol class="list-group list-group-numbered">
                <li class="list-group-item">Visit <a href="http://localhost/sports-gym-management/">http://localhost/sports-gym-management/</a></li>
                <li class="list-group-item">Login with admin credentials (admin@sportsgym.com / Admin@123)</li>
                <li class="list-group-item">Test CRUD operations in admin panel</li>
                <li class="list-group-item">Register a new user account</li>
                <li class="list-group-item">Test session registration as a user</li>
            </ol>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 