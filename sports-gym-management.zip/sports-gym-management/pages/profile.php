<?php
require_once '../config/db_connect.php';
require_once '../config/auth_check.php';

// Initialize messages
$success_msg = $error_msg = '';

// Get user data
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error_msg = "Failed to fetch user data.";
    error_log($e->getMessage());
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Validate input
    if (empty($username) || empty($email)) {
        $error_msg = "Username and email are required.";
    } else {
        try {
            // Check if username or email already exists (excluding current user)
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE (username = ? OR email = ?) AND id != ?");
            $stmt->execute([$username, $email, $_SESSION['user_id']]);
            if ($stmt->fetchColumn() > 0) {
                $error_msg = "Username or email already exists.";
            } else {
                // If password is being changed
                if (!empty($current_password)) {
                    // Verify current password
                    if (!password_verify($current_password, $user['password'])) {
                        $error_msg = "Current password is incorrect.";
                    } elseif (empty($new_password) || empty($confirm_password)) {
                        $error_msg = "New password and confirmation are required.";
                    } elseif ($new_password !== $confirm_password) {
                        $error_msg = "New passwords do not match.";
                    } else {
                        // Update with new password
                        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?");
                        $stmt->execute([$username, $email, password_hash($new_password, PASSWORD_DEFAULT), $_SESSION['user_id']]);
                        $success_msg = "Profile updated successfully with new password.";
                    }
                } else {
                    // Update without changing password
                    $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
                    $stmt->execute([$username, $email, $_SESSION['user_id']]);
                    $success_msg = "Profile updated successfully.";
                }

                // Refresh user data after update
                $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->execute([$_SESSION['user_id']]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        } catch (PDOException $e) {
            $error_msg = "Failed to update profile.";
            error_log($e->getMessage());
        }
    }
}

// Add booking cancellation handling at the top of the file after the profile update handling
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'cancel_booking') {
    $booking_id = (int)$_POST['booking_id'];
    
    try {
        $stmt = $pdo->prepare("
            UPDATE session_bookings 
            SET status = 'cancelled' 
            WHERE id = ? AND user_id = ? AND status = 'booked'
        ");
        
        if ($stmt->execute([$booking_id, $_SESSION['user_id']])) {
            $success_msg = "Booking cancelled successfully.";
        } else {
            $error_msg = "Failed to cancel booking.";
        }
    } catch (PDOException $e) {
        error_log("Error cancelling booking: " . $e->getMessage());
        $error_msg = "Failed to cancel booking.";
    }
}

// Get user's session bookings with debug information
try {
    // Debug: Check if user_id exists
    if (!isset($_SESSION['user_id'])) {
        error_log("User ID not found in session");
        throw new Exception("User not properly authenticated");
    }
    
    // First, check if the user has any bookings
    $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM session_bookings WHERE user_id = ?");
    $check_stmt->execute([$_SESSION['user_id']]);
    $booking_count = $check_stmt->fetchColumn();
    
    error_log("Found {$booking_count} bookings for user {$_SESSION['user_id']}");
    
    // Get detailed booking information
    $stmt = $pdo->prepare("
        SELECT 
            sb.id as booking_id,
            sb.booking_date,
            sb.status,
            s.id as session_id,
            s.session_name,
            s.trainer_name,
            s.schedule_day,
            s.start_time,
            s.end_time
        FROM session_bookings sb
        INNER JOIN sessions s ON sb.session_id = s.id
        WHERE sb.user_id = :user_id
        ORDER BY 
            CASE 
                WHEN sb.booking_date >= CURDATE() THEN 0 
                ELSE 1 
            END,
            sb.booking_date ASC,
            s.start_time ASC
    ");
    
    $stmt->execute(['user_id' => $_SESSION['user_id']]);
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    error_log("Fetched booking details: " . print_r($bookings, true));
    
} catch (Exception $e) {
    error_log("Error fetching bookings: " . $e->getMessage());
    $error_msg = "Failed to fetch session bookings.";
    $bookings = [];
}

include '../partials/header.php';
?>

<main class="container py-4">
    <div class="row">
        <!-- Profile Information -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title h5 mb-0">Profile Information</h2>
                </div>
                <div class="card-body">
                    <?php if ($success_msg): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo htmlspecialchars($success_msg); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if ($error_msg): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo htmlspecialchars($error_msg); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" class="needs-validation" novalidate>
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" 
                                   value="<?php echo htmlspecialchars($user['username']); ?>" required>
                            <div class="invalid-feedback">Please enter a username.</div>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            <div class="invalid-feedback">Please enter a valid email.</div>
                        </div>

                        <hr>
                        <h6>Change Password (Optional)</h6>

                        <div class="mb-3">
                            <label for="current_password" class="form-label">Current Password</label>
                            <input type="password" class="form-control" id="current_password" name="current_password">
                            <div class="form-text">Leave blank to keep current password.</div>
                        </div>

                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <input type="password" class="form-control" id="new_password" name="new_password">
                        </div>

                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                        </div>

                        <button type="submit" class="btn btn-primary">Update Profile</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Session Bookings -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title h5 mb-0">My Session Bookings</h2>
                </div>
                <div class="card-body">
                    <?php if (empty($bookings)): ?>
                        <p class="text-muted mb-0">
                            You haven't booked any sessions yet. 
                            <a href="../pages/sessions.php" class="btn btn-primary btn-sm ms-2">Book a Session</a>
                        </p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Session</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($bookings as $booking): ?>
                                        <tr>
                                            <td>
                                                <?php echo htmlspecialchars($booking['session_name']); ?><br>
                                                <small class="text-muted">
                                                    with <?php echo htmlspecialchars($booking['trainer_name']); ?>
                                                </small>
                                            </td>
                                            <td>
                                                <?php echo date('M d, Y', strtotime($booking['booking_date'])); ?><br>
                                                <small class="text-muted">
                                                    <?php echo htmlspecialchars($booking['schedule_day']); ?>
                                                </small>
                                            </td>
                                            <td>
                                                <?php 
                                                echo date('g:i A', strtotime($booking['start_time'])) . ' - ' . 
                                                     date('g:i A', strtotime($booking['end_time'])); 
                                                ?>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $booking['status'] === 'booked' ? 'success' : 
                                                        ($booking['status'] === 'cancelled' ? 'danger' : 'info'); 
                                                ?>">
                                                    <?php echo ucfirst(htmlspecialchars($booking['status'])); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($booking['status'] === 'booked' && strtotime($booking['booking_date']) >= strtotime('today')): ?>
                                                    <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to cancel this booking?');">
                                                        <input type="hidden" name="action" value="cancel_booking">
                                                        <input type="hidden" name="booking_id" value="<?php echo $booking['booking_id']; ?>">
                                                        <button type="submit" class="btn btn-danger btn-sm">Cancel</button>
                                                    </form>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-3">
                            <a href="../pages/sessions.php" class="btn btn-primary">Book More Sessions</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
// Form validation
(function () {
    'use strict'
    var forms = document.querySelectorAll('.needs-validation')
    Array.prototype.slice.call(forms).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

<?php include '../partials/footer.php'; ?> 