<?php
require_once '../config/db_connect.php';
require_once '../config/auth_check.php';

// Fetch upcoming events
try {
    $stmt = $pdo->prepare("SELECT * FROM events 
                          WHERE event_date >= CURDATE() 
                          ORDER BY event_date ASC, start_time ASC 
                          LIMIT 10");
    $stmt->execute();
    $events = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log($e->getMessage());
    $events = [];
}
?>

<?php include '../partials/header.php'; ?>

<main class="container py-4">
    <h1 class="mb-4">Upcoming Events</h1>

    <?php if (empty($events)): ?>
        <div class="alert alert-info">
            No upcoming events scheduled at the moment.
        </div>
    <?php else: ?>
        <div class="row">
            <?php foreach ($events as $event): ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($event['title']); ?></h5>
                            <p class="card-text text-muted">
                                <i class="fas fa-calendar-alt me-2"></i>
                                <?php echo date('F d, Y', strtotime($event['event_date'])); ?>
                            </p>
                            <p class="card-text text-muted">
                                <i class="fas fa-clock me-2"></i>
                                <?php echo date('g:i A', strtotime($event['start_time'])); ?> - 
                                <?php echo date('g:i A', strtotime($event['end_time'])); ?>
                            </p>
                            <p class="card-text">
                                <?php echo nl2br(htmlspecialchars($event['description'])); ?>
                            </p>
                            <p class="card-text">
                                <small class="text-muted">
                                    <i class="fas fa-users me-2"></i>
                                    Maximum Participants: <?php echo htmlspecialchars($event['max_participants']); ?>
                                </small>
                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>

<?php include '../partials/footer.php'; ?> 