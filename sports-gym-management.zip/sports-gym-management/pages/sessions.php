<?php
require_once '../config/db_connect.php';
require_once '../config/auth_check.php';

$success_msg = $error_msg = '';

// Add this function at the top of the file after the require statements
function getNextDayDate($dayName) {
    $today = new DateTime();
    $days = [
        'Monday' => 1,
        'Tuesday' => 2,
        'Wednesday' => 3,
        'Thursday' => 4,
        'Friday' => 5,
        'Saturday' => 6,
        'Sunday' => 7,
    ];
    
    $currentDayNumber = $today->format('N');
    $targetDayNumber = $days[$dayName];
    
    if ($currentDayNumber < $targetDayNumber) {
        $daysToAdd = $targetDayNumber - $currentDayNumber;
    } else {
        $daysToAdd = 7 - ($currentDayNumber - $targetDayNumber);
    }
    
    $nextDate = $today->add(new DateInterval("P{$daysToAdd}D"));
    return $nextDate->format('Y-m-d');
}

// Handle session booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'book') {
    $session_id = (int)$_POST['session_id'];
    $booking_date = $_POST['booking_date'];

    try {
        // Check if user already has a booking for this session on this date
        $check_stmt = $pdo->prepare("
            SELECT COUNT(*) 
            FROM session_bookings 
            WHERE user_id = ? AND session_id = ? AND booking_date = ? AND status = 'booked'
        ");
        $check_stmt->execute([$_SESSION['user_id'], $session_id, $booking_date]);
        
        if ($check_stmt->fetchColumn() > 0) {
            $error_msg = "You have already booked this session for this date.";
        } else {
            // Check if session is full for this date
            $capacity_stmt = $pdo->prepare("
                SELECT s.capacity, COUNT(sb.id) as booked
                FROM sessions s
                LEFT JOIN session_bookings sb ON s.id = sb.session_id 
                    AND sb.booking_date = ? 
                    AND sb.status = 'booked'
                WHERE s.id = ?
                GROUP BY s.id
            ");
            $capacity_stmt->execute([$booking_date, $session_id]);
            $capacity_info = $capacity_stmt->fetch(PDO::FETCH_ASSOC);

            if ($capacity_info && $capacity_info['booked'] < $capacity_info['capacity']) {
                // Create the booking
                $stmt = $pdo->prepare("
                    INSERT INTO session_bookings (user_id, session_id, booking_date, status) 
                    VALUES (?, ?, ?, 'booked')
                ");
                if ($stmt->execute([$_SESSION['user_id'], $session_id, $booking_date])) {
                    $success_msg = "Session booked successfully!";
                } else {
                    $error_msg = "Failed to book session.";
                }
            } else {
                $error_msg = "This session is full for the selected date.";
            }
        }
    } catch (PDOException $e) {
        error_log("Booking error: " . $e->getMessage());
        $error_msg = "Failed to process booking.";
    }
}

// Fetch all available sessions
try {
    $stmt = $pdo->prepare("
        SELECT s.*, 
            (SELECT COUNT(*) 
             FROM session_bookings sb 
             WHERE sb.session_id = s.id 
             AND sb.booking_date = CURDATE() 
             AND sb.status = 'booked') as today_bookings
        FROM sessions s
        ORDER BY s.schedule_day, s.start_time
    ");
    $stmt->execute();
    $sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching sessions: " . $e->getMessage());
    $error_msg = "Failed to fetch available sessions.";
    $sessions = [];
}

include '../partials/header.php';
?>

<main class="container py-4">
    <h1 class="mb-4">Available Sessions</h1>

    <?php if ($success_msg): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($success_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <?php foreach ($sessions as $session): ?>
            <div class="col">
                <div class="card h-100">
                    <div class="card-header">
                        <h5 class="card-title mb-0"><?php echo htmlspecialchars($session['session_name']); ?></h5>
                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            <strong>Trainer:</strong> <?php echo htmlspecialchars($session['trainer_name']); ?><br>
                            <strong>Day:</strong> <?php echo htmlspecialchars($session['schedule_day']); ?><br>
                            <strong>Time:</strong> <?php echo date('g:i A', strtotime($session['start_time'])) . ' - ' . 
                                                           date('g:i A', strtotime($session['end_time'])); ?><br>
                            <strong>Capacity:</strong> <?php echo htmlspecialchars($session['capacity']); ?> people<br>
                            <?php if ($session['description']): ?>
                                <strong>Description:</strong> <?php echo htmlspecialchars($session['description']); ?>
                            <?php endif; ?>
                        </p>
                        
                        <button type="button" class="btn btn-primary" 
                                data-bs-toggle="modal" 
                                data-bs-target="#bookSessionModal<?php echo $session['id']; ?>">
                            Book Session
                        </button>
                    </div>
                </div>
            </div>

            <!-- Booking Modal -->
            <div class="modal fade" id="bookSessionModal<?php echo $session['id']; ?>" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Book <?php echo htmlspecialchars($session['session_name']); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <form method="POST">
                            <div class="modal-body">
                                <input type="hidden" name="action" value="book">
                                <input type="hidden" name="session_id" value="<?php echo $session['id']; ?>">
                                <?php $nextDate = getNextDayDate($session['schedule_day']); ?>
                                <input type="hidden" name="booking_date" value="<?php echo $nextDate; ?>">
                                
                                <div class="alert alert-info">
                                    <h6 class="mb-2">Session Details:</h6>
                                    <p class="mb-1">
                                        <strong>Date:</strong> <?php echo date('l, F j, Y', strtotime($nextDate)); ?><br>
                                        <strong>Time:</strong> <?php echo date('g:i A', strtotime($session['start_time'])) . ' - ' . 
                                                    date('g:i A', strtotime($session['end_time'])); ?><br>
                                        <strong>Trainer:</strong> <?php echo htmlspecialchars($session['trainer_name']); ?>
                                    </p>
                                </div>

                                <p class="mb-0">
                                    <small class="text-muted">
                                        This session will be scheduled for the next available <?php echo $session['schedule_day']; ?>.
                                    </small>
                                </p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Confirm Booking</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</main>

<script>
// Form validation for other fields if needed
(function () {
    'use strict'
    var forms = document.querySelectorAll('.needs-validation')
    Array.prototype.slice.call(forms).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

<?php include '../partials/footer.php'; ?> 