<?php
require_once '../config/db_connect.php';
require_once '../config/auth_check.php';

$success_msg = $error_msg = '';

// Fetch user-specific data
try {
    $userId = $_SESSION['user_id'];
    $stmt = $pdo->prepare("SELECT COUNT(*) as total_achievements FROM achievements WHERE user_id = ?");
    $stmt->execute([$userId]);
    $totalAchievements = $stmt->fetch()['total_achievements'];
} catch (PDOException $e) {
    error_log($e->getMessage());
    $totalAchievements = 0;
}

try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as total_sessions FROM session_bookings WHERE user_id = ? AND booking_date >= CURDATE()");
    $stmt->execute([$userId]);
    $upcomingSessions = $stmt->fetch()['total_sessions'];
} catch (PDOException $e) {
    error_log($e->getMessage());
    $upcomingSessions = 0;
}

try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as total_events FROM event_registrations WHERE user_id = ? AND status = 'registered'");
    $stmt->execute([$userId]);
    $registeredEvents = $stmt->fetch()['total_events'];
} catch (PDOException $e) {
    error_log($e->getMessage());
    $registeredEvents = 0;
}
?>

<?php include '../partials/header.php'; ?>

<main class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Member Dashboard</h1>
        <span class="text-muted">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5 class="card-title">Achievements</h5>
                    <h2 class="card-text"><?php echo $totalAchievements; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title">Upcoming Sessions</h5>
                    <h2 class="card-text"><?php echo $upcomingSessions; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h5 class="card-title">Registered Events</h5>
                    <h2 class="card-text"><?php echo $registeredEvents; ?></h2>
                </div>
            </div>
        </div>
    </div>

    <!-- Management Options -->
    <div class="row">
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">View Achievements</h5>
                    <p class="card-text">Check your achievements and milestones.</p>
                    <a href="achievements.php" class="btn btn-primary">View Achievements</a>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Upcoming Sessions</h5>
                    <p class="card-text">View and manage your session bookings.</p>
                    <a href="sessions.php" class="btn btn-primary">View Sessions</a>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Registered Events</h5>
                    <p class="card-text">See the events you are registered for.</p>
                    <a href="events.php" class="btn btn-primary">View Events</a>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include '../partials/footer.php'; ?> 