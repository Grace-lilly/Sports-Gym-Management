<?php
require_once '../config/db_connect.php';
require_once '../config/auth_check.php';

// Fetch recent achievements with user information
try {
    $stmt = $pdo->prepare("SELECT a.*, u.username 
                          FROM achievements a 
                          LEFT JOIN users u ON a.user_id = u.id 
                          ORDER BY a.achievement_date DESC 
                          LIMIT 20");
    $stmt->execute();
    $achievements = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log($e->getMessage());
    $achievements = [];
}

// Group achievements by month and year
$grouped_achievements = [];
foreach ($achievements as $achievement) {
    $date = date('F Y', strtotime($achievement['achievement_date']));
    if (!isset($grouped_achievements[$date])) {
        $grouped_achievements[$date] = [];
    }
    $grouped_achievements[$date][] = $achievement;
}
?>

<?php include '../partials/header.php'; ?>

<main class="container py-4">
    <h1 class="mb-4">Achievement Showcase</h1>

    <?php if (empty($achievements)): ?>
        <div class="alert alert-info">
            No achievements have been awarded yet.
        </div>
    <?php else: ?>
        <div class="timeline">
            <?php foreach ($grouped_achievements as $date => $month_achievements): ?>
                <div class="row mb-4">
                    <div class="col-12">
                        <h3 class="text-muted border-bottom pb-2"><?php echo $date; ?></h3>
                    </div>
                </div>
                <div class="row">
                    <?php foreach ($month_achievements as $achievement): ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="card h-100 shadow-sm achievement-card">
                                <div class="card-body">
                                    <div class="achievement-icon mb-3">
                                        <i class="fas fa-trophy text-warning fa-2x"></i>
                                    </div>
                                    <h5 class="card-title"><?php echo htmlspecialchars($achievement['title']); ?></h5>
                                    <p class="card-text">
                                        <?php echo nl2br(htmlspecialchars($achievement['description'])); ?>
                                    </p>
                                    <p class="card-text">
                                        <small class="text-muted">
                                            <i class="fas fa-user me-2"></i>
                                            Awarded to: <?php echo htmlspecialchars($achievement['username']); ?>
                                        </small>
                                    </p>
                                    <p class="card-text">
                                        <small class="text-muted">
                                            <i class="fas fa-calendar-alt me-2"></i>
                                            <?php echo date('F d, Y', strtotime($achievement['achievement_date'])); ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>

<style>
.achievement-card {
    transition: transform 0.2s;
}
.achievement-card:hover {
    transform: translateY(-5px);
}
.achievement-icon {
    text-align: center;
}
</style>

<?php include '../partials/footer.php'; ?> 