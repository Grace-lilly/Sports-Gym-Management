<?php
require_once '../../config/db_connect.php';
require_once '../../config/auth_check.php';
requireAdmin();

$success_msg = $error_msg = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $name = trim($_POST['name'] ?? '');
                $description = trim($_POST['description'] ?? '');
                $quantity = (int)($_POST['quantity'] ?? 0);
                
                try {
                    $stmt = $pdo->prepare("INSERT INTO equipment (name, description, quantity) VALUES (?, ?, ?)");
                    $stmt->execute([$name, $description, $quantity]);
                    $success_msg = "Equipment added successfully!";
                } catch (PDOException $e) {
                    $error_msg = "Failed to add equipment.";
                    error_log($e->getMessage());
                }
                break;

            case 'delete':
                $id = (int)($_POST['id'] ?? 0);
                try {
                    $stmt = $pdo->prepare("DELETE FROM equipment WHERE id = ?");
                    $stmt->execute([$id]);
                    $success_msg = "Equipment deleted successfully!";
                } catch (PDOException $e) {
                    $error_msg = "Failed to delete equipment.";
                    error_log($e->getMessage());
                }
                break;
        }
    }
}

// Fetch all equipment
try {
    $stmt = $pdo->query("SELECT * FROM equipment ORDER BY name");
    $equipment = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_msg = "Failed to fetch equipment.";
    error_log($e->getMessage());
    $equipment = [];
}
?>

<?php include '../../partials/header.php'; ?>

<main class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Equipment Management</h1>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEquipmentModal">
            Add New Equipment
        </button>
    </div>

    <?php if ($success_msg): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success_msg); ?></div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error_msg); ?></div>
    <?php endif; ?>

    <!-- Equipment List -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Quantity</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($equipment as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                <td><?php echo htmlspecialchars($item['description']); ?></td>
                                <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-warning me-1" 
                                            onclick="editEquipment(<?php echo $item['id']; ?>)">Edit</button>
                                    <form method="POST" class="d-inline" 
                                          onsubmit="return confirm('Are you sure you want to delete this item?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<!-- Add Equipment Modal -->
<div class="modal fade" id="addEquipmentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Equipment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="name" class="form-label">Equipment Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="quantity" class="form-label">Quantity</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" min="0" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Equipment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../../partials/footer.php'; ?> 