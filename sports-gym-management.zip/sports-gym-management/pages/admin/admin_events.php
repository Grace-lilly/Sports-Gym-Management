<?php
require_once '../../config/db_connect.php';
require_once '../../config/auth_check.php';
requireAdmin();

$success_msg = $error_msg = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $title = trim($_POST['title'] ?? '');
                $description = trim($_POST['description'] ?? '');
                $event_date = $_POST['event_date'] ?? '';
                $start_time = $_POST['start_time'] ?? '';
                $end_time = $_POST['end_time'] ?? '';
                $location = trim($_POST['location'] ?? '');
                $max_participants = (int)($_POST['max_participants'] ?? 0);
                $status = $_POST['status'] ?? 'upcoming';

                if (empty($title) || empty($event_date)) {
                    $error_msg = "Please provide all required event details.";
                } else {
                    try {
                        $stmt = $pdo->prepare("INSERT INTO events (title, description, event_date, start_time, end_time, location, max_participants, status) 
                                             VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$title, $description, $event_date, $start_time, $end_time, $location, $max_participants, $status]);
                        $success_msg = "Event added successfully!";
                    } catch (PDOException $e) {
                        $error_msg = "Failed to add event.";
                        error_log($e->getMessage());
                    }
                }
                break;

            case 'update':
                $id = (int)($_POST['id'] ?? 0);
                $title = trim($_POST['title'] ?? '');
                $description = trim($_POST['description'] ?? '');
                $event_date = $_POST['event_date'] ?? '';
                $start_time = $_POST['start_time'] ?? '';
                $end_time = $_POST['end_time'] ?? '';
                $location = trim($_POST['location'] ?? '');
                $max_participants = (int)($_POST['max_participants'] ?? 0);
                $status = $_POST['status'] ?? 'upcoming';

                if (empty($title) || empty($event_date)) {
                    $error_msg = "Please provide all required event details.";
                } else {
                    try {
                        $stmt = $pdo->prepare("UPDATE events SET title = ?, description = ?, event_date = ?, 
                                             start_time = ?, end_time = ?, location = ?, max_participants = ?, 
                                             status = ? WHERE id = ?");
                        $stmt->execute([$title, $description, $event_date, $start_time, $end_time, 
                                      $location, $max_participants, $status, $id]);
                        $success_msg = "Event updated successfully!";
                    } catch (PDOException $e) {
                        $error_msg = "Failed to update event.";
                        error_log($e->getMessage());
                    }
                }
                break;

            case 'delete':
                $id = (int)($_POST['id'] ?? 0);
                try {
                    $stmt = $pdo->prepare("DELETE FROM events WHERE id = ?");
                    $stmt->execute([$id]);
                    $success_msg = "Event deleted successfully!";
                } catch (PDOException $e) {
                    $error_msg = "Failed to delete event.";
                    error_log($e->getMessage());
                }
                break;
        }
    }
}

// Fetch all events
try {
    $stmt = $pdo->query("SELECT * FROM events ORDER BY event_date DESC");
    $events = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_msg = "Failed to fetch events.";
    error_log($e->getMessage());
    $events = [];
}
?>

<?php include '../../partials/header.php'; ?>

<main class="container py-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Event Management</h1>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEventModal">
            <i class="fas fa-plus"></i> Add New Event
        </button>
    </div>

    <!-- Alert Messages -->
    <?php if ($success_msg): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($success_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Events List -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Title</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Location</th>
                            <th>Participants</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($events as $event): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($event['title']); ?></strong>
                                    <br>
                                    <small class="text-muted">
                                        <?php echo nl2br(htmlspecialchars($event['description'])); ?>
                                    </small>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($event['event_date'])); ?></td>
                                <td>
                                    <?php 
                                    echo $event['start_time'] ? date('g:i A', strtotime($event['start_time'])) : 'N/A';
                                    if ($event['end_time']) {
                                        echo ' - ' . date('g:i A', strtotime($event['end_time']));
                                    }
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($event['location']); ?></td>
                                <td><?php echo htmlspecialchars($event['max_participants']); ?></td>
                                <td>
                                    <?php
                                    $status_class = match($event['status']) {
                                        'upcoming' => 'bg-primary',
                                        'ongoing' => 'bg-success',
                                        'completed' => 'bg-secondary',
                                        'cancelled' => 'bg-danger',
                                        default => 'bg-secondary'
                                    };
                                    ?>
                                    <span class="badge <?php echo $status_class; ?>">
                                        <?php echo ucfirst(htmlspecialchars($event['status'])); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-warning me-1" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editEventModal<?php echo $event['id']; ?>">
                                        Edit
                                    </button>
                                    <form method="POST" class="d-inline" 
                                          onsubmit="return confirm('Are you sure you want to delete this event?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $event['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>

                            <!-- Edit Event Modal -->
                            <div class="modal fade" id="editEventModal<?php echo $event['id']; ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit Event</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form method="POST">
                                            <div class="modal-body">
                                                <input type="hidden" name="action" value="update">
                                                <input type="hidden" name="id" value="<?php echo $event['id']; ?>">
                                                
                                                <div class="mb-3">
                                                    <label for="title<?php echo $event['id']; ?>" class="form-label">Event Title</label>
                                                    <input type="text" class="form-control" id="title<?php echo $event['id']; ?>" 
                                                           name="title" value="<?php echo htmlspecialchars($event['title']); ?>" required>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label for="description<?php echo $event['id']; ?>" class="form-label">Description</label>
                                                    <textarea class="form-control" id="description<?php echo $event['id']; ?>" 
                                                              name="description" rows="3"><?php echo htmlspecialchars($event['description']); ?></textarea>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="event_date<?php echo $event['id']; ?>" class="form-label">Event Date</label>
                                                    <input type="date" class="form-control" id="event_date<?php echo $event['id']; ?>" 
                                                           name="event_date" value="<?php echo $event['event_date']; ?>" required>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <label for="start_time<?php echo $event['id']; ?>" class="form-label">Start Time</label>
                                                        <input type="time" class="form-control" id="start_time<?php echo $event['id']; ?>" 
                                                               name="start_time" value="<?php echo $event['start_time']; ?>">
                                                    </div>
                                                    <div class="col-md-6 mb-3">
                                                        <label for="end_time<?php echo $event['id']; ?>" class="form-label">End Time</label>
                                                        <input type="time" class="form-control" id="end_time<?php echo $event['id']; ?>" 
                                                               name="end_time" value="<?php echo $event['end_time']; ?>">
                                                    </div>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="location<?php echo $event['id']; ?>" class="form-label">Location</label>
                                                    <input type="text" class="form-control" id="location<?php echo $event['id']; ?>" 
                                                           name="location" value="<?php echo htmlspecialchars($event['location']); ?>">
                                                </div>

                                                <div class="mb-3">
                                                    <label for="max_participants<?php echo $event['id']; ?>" class="form-label">Maximum Participants</label>
                                                    <input type="number" class="form-control" id="max_participants<?php echo $event['id']; ?>" 
                                                           name="max_participants" value="<?php echo $event['max_participants']; ?>" min="0">
                                                </div>

                                                <div class="mb-3">
                                                    <label for="status<?php echo $event['id']; ?>" class="form-label">Status</label>
                                                    <select class="form-select" id="status<?php echo $event['id']; ?>" name="status">
                                                        <option value="upcoming" <?php echo $event['status'] === 'upcoming' ? 'selected' : ''; ?>>Upcoming</option>
                                                        <option value="ongoing" <?php echo $event['status'] === 'ongoing' ? 'selected' : ''; ?>>Ongoing</option>
                                                        <option value="completed" <?php echo $event['status'] === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                                        <option value="cancelled" <?php echo $event['status'] === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Update Event</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<!-- Add Event Modal -->
<div class="modal fade" id="addEventModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Event</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="title" class="form-label">Event Title</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="event_date" class="form-label">Event Date</label>
                        <input type="date" class="form-control" id="event_date" name="event_date" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="start_time" class="form-label">Start Time</label>
                            <input type="time" class="form-control" id="start_time" name="start_time">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="end_time" class="form-label">End Time</label>
                            <input type="time" class="form-control" id="end_time" name="end_time">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="location" class="form-label">Location</label>
                        <input type="text" class="form-control" id="location" name="location">
                    </div>

                    <div class="mb-3">
                        <label for="max_participants" class="form-label">Maximum Participants</label>
                        <input type="number" class="form-control" id="max_participants" name="max_participants" min="0" value="0">
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" id="status" name="status">
                            <option value="upcoming">Upcoming</option>
                            <option value="ongoing">Ongoing</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Event</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../../partials/footer.php'; ?> 