<?php
require_once '../../config/db_connect.php';
require_once '../../config/auth_check.php';
requireAdmin();

$success_msg = $error_msg = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $title = trim($_POST['title'] ?? '');
                $description = trim($_POST['description'] ?? '');
                $user_id = (int)($_POST['user_id'] ?? 0);
                $achievement_date = $_POST['achievement_date'] ?? date('Y-m-d');

                if (empty($title) || empty($user_id)) {
                    $error_msg = "Please provide all required achievement details.";
                } else {
                    try {
                        $stmt = $pdo->prepare("INSERT INTO achievements (title, description, user_id, achievement_date) 
                                             VALUES (?, ?, ?, ?)");
                        $stmt->execute([$title, $description, $user_id, $achievement_date]);
                        $success_msg = "Achievement added successfully!";
                    } catch (PDOException $e) {
                        $error_msg = "Failed to add achievement.";
                        error_log($e->getMessage());
                    }
                }
                break;

            case 'update':
                $id = (int)($_POST['id'] ?? 0);
                $title = trim($_POST['title'] ?? '');
                $description = trim($_POST['description'] ?? '');
                $user_id = (int)($_POST['user_id'] ?? 0);
                $achievement_date = $_POST['achievement_date'] ?? date('Y-m-d');

                if (empty($title) || empty($user_id)) {
                    $error_msg = "Please provide all required achievement details.";
                } else {
                    try {
                        $stmt = $pdo->prepare("UPDATE achievements SET title = ?, description = ?, 
                                             user_id = ?, achievement_date = ? WHERE id = ?");
                        $stmt->execute([$title, $description, $user_id, $achievement_date, $id]);
                        $success_msg = "Achievement updated successfully!";
                    } catch (PDOException $e) {
                        $error_msg = "Failed to update achievement.";
                        error_log($e->getMessage());
                    }
                }
                break;

            case 'delete':
                $id = (int)($_POST['id'] ?? 0);
                try {
                    $stmt = $pdo->prepare("DELETE FROM achievements WHERE id = ?");
                    $stmt->execute([$id]);
                    $success_msg = "Achievement deleted successfully!";
                } catch (PDOException $e) {
                    $error_msg = "Failed to delete achievement.";
                    error_log($e->getMessage());
                }
                break;
        }
    }
}

// Fetch all achievements with user information
try {
    $stmt = $pdo->query("SELECT a.*, u.username 
                         FROM achievements a 
                         JOIN users u ON a.user_id = u.id 
                         ORDER BY a.achievement_date DESC");
    $achievements = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_msg = "Failed to fetch achievements.";
    error_log($e->getMessage());
    $achievements = [];
}

// Fetch all users for the dropdown
try {
    $stmt = $pdo->query("SELECT id, username FROM users WHERE role = 'user' ORDER BY username");
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log($e->getMessage());
    $users = [];
}
?>

<?php include '../../partials/header.php'; ?>

<main class="container py-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Achievement Management</h1>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAchievementModal">
            <i class="fas fa-plus"></i> Add New Achievement
        </button>
    </div>

    <!-- Alert Messages -->
    <?php if ($success_msg): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($success_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Achievements List -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Member</th>
                            <th>Achievement</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($achievements as $achievement): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($achievement['username']); ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($achievement['title']); ?></strong>
                                    <br>
                                    <small class="text-muted">
                                        <?php echo nl2br(htmlspecialchars($achievement['description'])); ?>
                                    </small>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($achievement['achievement_date'])); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-warning me-1" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editAchievementModal<?php echo $achievement['id']; ?>">
                                        Edit
                                    </button>
                                    <form method="POST" class="d-inline" 
                                          onsubmit="return confirm('Are you sure you want to delete this achievement?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $achievement['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>

                            <!-- Edit Achievement Modal -->
                            <div class="modal fade" id="editAchievementModal<?php echo $achievement['id']; ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit Achievement</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form method="POST">
                                            <div class="modal-body">
                                                <input type="hidden" name="action" value="update">
                                                <input type="hidden" name="id" value="<?php echo $achievement['id']; ?>">
                                                
                                                <div class="mb-3">
                                                    <label for="user_id<?php echo $achievement['id']; ?>" class="form-label">Member</label>
                                                    <select class="form-select" id="user_id<?php echo $achievement['id']; ?>" 
                                                            name="user_id" required>
                                                        <?php foreach ($users as $user): ?>
                                                            <option value="<?php echo $user['id']; ?>" 
                                                                <?php echo $user['id'] === $achievement['user_id'] ? 'selected' : ''; ?>>
                                                                <?php echo htmlspecialchars($user['username']); ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="title<?php echo $achievement['id']; ?>" class="form-label">Achievement Title</label>
                                                    <input type="text" class="form-control" id="title<?php echo $achievement['id']; ?>" 
                                                           name="title" value="<?php echo htmlspecialchars($achievement['title']); ?>" required>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label for="description<?php echo $achievement['id']; ?>" class="form-label">Description</label>
                                                    <textarea class="form-control" id="description<?php echo $achievement['id']; ?>" 
                                                              name="description" rows="3"><?php echo htmlspecialchars($achievement['description']); ?></textarea>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="achievement_date<?php echo $achievement['id']; ?>" class="form-label">Achievement Date</label>
                                                    <input type="date" class="form-control" id="achievement_date<?php echo $achievement['id']; ?>" 
                                                           name="achievement_date" value="<?php echo $achievement['achievement_date']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Update Achievement</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<!-- Add Achievement Modal -->
<div class="modal fade" id="addAchievementModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Achievement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="user_id" class="form-label">Member</label>
                        <select class="form-select" id="user_id" name="user_id" required>
                            <option value="">Select Member</option>
                            <?php foreach ($users as $user): ?>
                                <option value="<?php echo $user['id']; ?>">
                                    <?php echo htmlspecialchars($user['username']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="title" class="form-label">Achievement Title</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="achievement_date" class="form-label">Achievement Date</label>
                        <input type="date" class="form-control" id="achievement_date" name="achievement_date" 
                               value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Achievement</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../../partials/footer.php'; ?> 