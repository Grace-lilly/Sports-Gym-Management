<?php
require_once '../../config/db_connect.php';
require_once '../../config/auth_check.php';
requireAdmin();

$success_msg = $error_msg = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $name = trim($_POST['name'] ?? '');
                $description = trim($_POST['description'] ?? '');
                $quantity = (int)($_POST['quantity'] ?? 0);
                $status = $_POST['status'] ?? 'available';

                if (empty($name) || $quantity < 0) {
                    $error_msg = "Please provide valid equipment details.";
                } else {
                    try {
                        $stmt = $pdo->prepare("INSERT INTO equipment (name, description, quantity, status) VALUES (?, ?, ?, ?)");
                        $stmt->execute([$name, $description, $quantity, $status]);
                        $success_msg = "Equipment added successfully!";
                    } catch (PDOException $e) {
                        $error_msg = "Failed to add equipment.";
                        error_log($e->getMessage());
                    }
                }
                break;

            case 'update':
                $id = (int)($_POST['id'] ?? 0);
                $quantity = (int)($_POST['quantity'] ?? 0);
                $status = $_POST['status'] ?? 'available';

                try {
                    $stmt = $pdo->prepare("UPDATE equipment SET quantity = ?, status = ? WHERE id = ?");
                    $stmt->execute([$quantity, $status, $id]);
                    $success_msg = "Equipment updated successfully!";
                } catch (PDOException $e) {
                    $error_msg = "Failed to update equipment.";
                    error_log($e->getMessage());
                }
                break;

            case 'delete':
                $id = (int)($_POST['id'] ?? 0);
                try {
                    $stmt = $pdo->prepare("DELETE FROM equipment WHERE id = ?");
                    $stmt->execute([$id]);
                    $success_msg = "Equipment deleted successfully!";
                } catch (PDOException $e) {
                    $error_msg = "Failed to delete equipment.";
                    error_log($e->getMessage());
                }
                break;
        }
    }
}

// Fetch all equipment
try {
    $stmt = $pdo->query("SELECT * FROM equipment ORDER BY name");
    $equipment = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_msg = "Failed to fetch equipment.";
    error_log($e->getMessage());
    $equipment = [];
}
?>

<?php include '../../partials/header.php'; ?>

<main class="container py-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Equipment Management</h1>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEquipmentModal">
            <i class="fas fa-plus"></i> Add New Equipment
        </button>
    </div>

    <!-- Alert Messages -->
    <?php if ($success_msg): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($success_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Equipment List -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Quantity</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($equipment as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['id']); ?></td>
                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                <td><?php echo htmlspecialchars($item['description']); ?></td>
                                <td>
                                    <form method="POST" class="d-inline quantity-form">
                                        <input type="hidden" name="action" value="update">
                                        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                                        <input type="number" class="form-control form-control-sm d-inline-block" 
                                               style="width: 80px;" name="quantity" 
                                               value="<?php echo htmlspecialchars($item['quantity']); ?>" min="0">
                                    </form>
                                </td>
                                <td>
                                    <form method="POST" class="d-inline status-form">
                                        <input type="hidden" name="action" value="update">
                                        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                                        <select class="form-select form-select-sm" name="status" style="width: 130px;">
                                            <option value="available" <?php echo $item['status'] === 'available' ? 'selected' : ''; ?>>
                                                Available
                                            </option>
                                            <option value="maintenance" <?php echo $item['status'] === 'maintenance' ? 'selected' : ''; ?>>
                                                Maintenance
                                            </option>
                                            <option value="retired" <?php echo $item['status'] === 'retired' ? 'selected' : ''; ?>>
                                                Retired
                                            </option>
                                        </select>
                                    </form>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-warning me-1" 
                                            onclick="updateEquipment(<?php echo $item['id']; ?>)">
                                        Update
                                    </button>
                                    <form method="POST" class="d-inline" 
                                          onsubmit="return confirm('Are you sure you want to delete this equipment?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<!-- Add Equipment Modal -->
<div class="modal fade" id="addEquipmentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Equipment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="name" class="form-label">Equipment Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="quantity" class="form-label">Quantity</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" min="0" required>
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="available">Available</option>
                            <option value="maintenance">Maintenance</option>
                            <option value="retired">Retired</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Equipment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JavaScript for form handling -->
<script>
function updateEquipment(id) {
    const row = event.target.closest('tr');
    const quantityForm = row.querySelector('.quantity-form');
    const statusForm = row.querySelector('.status-form');
    
    // Copy the quantity value to the status form
    const quantityInput = quantityForm.querySelector('input[name="quantity"]');
    const statusSelect = statusForm.querySelector('select[name="status"]');
    
    const combinedForm = document.createElement('form');
    combinedForm.method = 'POST';
    combinedForm.innerHTML = `
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" value="${id}">
        <input type="hidden" name="quantity" value="${quantityInput.value}">
        <input type="hidden" name="status" value="${statusSelect.value}">
    `;
    
    document.body.appendChild(combinedForm);
    combinedForm.submit();
}
</script>

<?php include '../../partials/footer.php'; ?> 