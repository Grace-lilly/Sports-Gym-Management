<?php
require_once '../../config/db_connect.php';
require_once '../../config/auth_check.php';
requireAdmin();

// Fetch session statistics
try {
    // Get upcoming sessions with registration counts
    $stmt = $pdo->prepare("
        SELECT 
            s.*,
            COUNT(DISTINCT sb.user_id) as registered_count,
            s.capacity - COUNT(DISTINCT sb.user_id) as spots_left,
            GROUP_CONCAT(
                DISTINCT CONCAT(u.username, ' (', DATE_FORMAT(sb.booking_date, '%Y-%m-%d'), ')')
                ORDER BY sb.booking_date ASC
                SEPARATOR ', '
            ) as registered_members
        FROM sessions s
        LEFT JOIN session_bookings sb ON s.id = sb.session_id AND sb.status = 'booked'
        LEFT JOIN users u ON sb.user_id = u.id
        GROUP BY s.id
        ORDER BY s.schedule_day, s.start_time
    ");
    $stmt->execute();
    $sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get total statistics
    $stats_stmt = $pdo->prepare("
        SELECT 
            (SELECT COUNT(*) FROM users WHERE role = 'user') as total_members,
            (SELECT COUNT(*) FROM sessions) as total_sessions,
            (SELECT COUNT(*) FROM session_bookings WHERE status = 'booked') as total_bookings,
            (SELECT COUNT(DISTINCT user_id) FROM session_bookings WHERE status = 'booked') as active_members
    ");
    $stats_stmt->execute();
    $stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Error fetching dashboard data: " . $e->getMessage());
}

include '../../partials/header.php';
?>

<main class="container py-4">
    <h1 class="mb-4">Admin Dashboard</h1>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="card bg-primary text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Total Members</h5>
                    <h2 class="card-text"><?php echo $stats['total_members']; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card bg-success text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Active Members</h5>
                    <h2 class="card-text"><?php echo $stats['active_members']; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card bg-info text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Total Sessions</h5>
                    <h2 class="card-text"><?php echo $stats['total_sessions']; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card bg-warning text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Total Bookings</h5>
                    <h2 class="card-text"><?php echo $stats['total_bookings']; ?></h2>
                </div>
            </div>
        </div>
    </div>

    <!-- Session Registration Details -->
    <div class="card mb-4">
        <div class="card-header">
            <h2 class="card-title h5 mb-0">Session Registration Details</h2>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Session</th>
                            <th>Schedule</th>
                            <th>Capacity</th>
                            <th>Registered</th>
                            <th>Members</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sessions as $session): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($session['session_name']); ?></strong><br>
                                    <small class="text-muted">with <?php echo htmlspecialchars($session['trainer_name']); ?></small>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($session['schedule_day']); ?><br>
                                    <small class="text-muted">
                                        <?php echo date('g:i A', strtotime($session['start_time'])) . ' - ' . 
                                                 date('g:i A', strtotime($session['end_time'])); ?>
                                    </small>
                                </td>
                                <td><?php echo $session['capacity']; ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1 me-2">
                                            <div class="progress" style="height: 20px;">
                                                <?php 
                                                $percentage = ($session['registered_count'] / $session['capacity']) * 100;
                                                $bg_class = $percentage >= 90 ? 'bg-danger' : 
                                                           ($percentage >= 70 ? 'bg-warning' : 'bg-success');
                                                ?>
                                                <div class="progress-bar <?php echo $bg_class; ?>" 
                                                     role="progressbar" 
                                                     style="width: <?php echo $percentage; ?>%"
                                                     aria-valuenow="<?php echo $session['registered_count']; ?>" 
                                                     aria-valuemin="0" 
                                                     aria-valuemax="<?php echo $session['capacity']; ?>">
                                                    <?php echo $session['registered_count']; ?>/<?php echo $session['capacity']; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($session['registered_count'] > 0): ?>
                                        <button type="button" 
                                                class="btn btn-sm btn-info" 
                                                data-bs-toggle="popover" 
                                                data-bs-trigger="focus" 
                                                data-bs-title="Registered Members"
                                                data-bs-content="<?php echo htmlspecialchars($session['registered_members']); ?>">
                                            View Members
                                        </button>
                                    <?php else: ?>
                                        <span class="text-muted">No registrations</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Quick Links -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title h5 mb-0">Quick Links</h2>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <a href="admin_sessions.php" class="btn btn-primary w-100">
                                <i class="fas fa-calendar-alt me-2"></i>Manage Sessions
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="admin_users.php" class="btn btn-success w-100">
                                <i class="fas fa-users me-2"></i>Manage Users
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="admin_equipment.php" class="btn btn-info w-100">
                                <i class="fas fa-dumbbell me-2"></i>Manage Equipment
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="admin_events.php" class="btn btn-warning w-100">
                                <i class="fas fa-calendar-check me-2"></i>Manage Events
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
// Initialize popovers
document.addEventListener('DOMContentLoaded', function() {
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl, {
            html: false,
            sanitize: true
        })
    })
})
</script>

<?php include '../../partials/footer.php'; ?> 