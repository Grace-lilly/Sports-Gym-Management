<?php
require_once '../../config/db_connect.php';
require_once '../../config/auth_check.php';
requireAdmin();

$success_msg = $error_msg = $info_msg = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $session_name = trim($_POST['session_name'] ?? '');
                $trainer_name = trim($_POST['trainer_name'] ?? '');
                $description = trim($_POST['description'] ?? '');
                $schedule_day = $_POST['schedule_day'] ?? '';
                $start_time = $_POST['start_time'] ?? '';
                $end_time = $_POST['end_time'] ?? '';
                $capacity = (int)($_POST['capacity'] ?? 10);

                if (empty($session_name) || empty($trainer_name) || empty($schedule_day) || empty($start_time) || empty($end_time)) {
                    $error_msg = "Please fill in all required fields (Session Name, Trainer Name, Schedule Day, Start Time, and End Time).";
                } else {
                    try {
                        $stmt = $pdo->prepare("INSERT INTO sessions (session_name, trainer_name, description, schedule_day, start_time, end_time, capacity) 
                                             VALUES (:session_name, :trainer_name, :description, :schedule_day, :start_time, :end_time, :capacity)");
                        $result = $stmt->execute([
                            ':session_name' => $session_name,
                            ':trainer_name' => $trainer_name,
                            ':description' => $description,
                            ':schedule_day' => $schedule_day,
                            ':start_time' => $start_time,
                            ':end_time' => $end_time,
                            ':capacity' => $capacity
                        ]);
                        
                        if ($result) {
                            $success_msg = "Session added successfully!";
                        } else {
                            $error_msg = "Failed to add session. Please try again.";
                        }
                    } catch (PDOException $e) {
                        $error_msg = "Database error: " . $e->getMessage();
                        error_log("Session add error: " . $e->getMessage());
                    }
                }
                break;

            case 'update':
                $id = (int)($_POST['id'] ?? 0);
                $session_name = trim($_POST['session_name'] ?? '');
                $trainer_name = trim($_POST['trainer_name'] ?? '');
                $description = trim($_POST['description'] ?? '');
                $schedule_day = $_POST['schedule_day'] ?? '';
                $start_time = $_POST['start_time'] ?? '';
                $end_time = $_POST['end_time'] ?? '';
                $capacity = (int)($_POST['capacity'] ?? 10);

                if (empty($session_name) || empty($trainer_name) || empty($schedule_day)) {
                    $error_msg = "Please provide all required session details.";
                } else {
                    try {
                        $stmt = $pdo->prepare("UPDATE sessions SET session_name = ?, trainer_name = ?, description = ?, 
                                             schedule_day = ?, start_time = ?, end_time = ?, capacity = ? WHERE id = ?");
                        $stmt->execute([$session_name, $trainer_name, $description, $schedule_day, $start_time, $end_time, $capacity, $id]);
                        $success_msg = "Session updated successfully!";
                    } catch (PDOException $e) {
                        $error_msg = "Failed to update session.";
                        error_log($e->getMessage());
                    }
                }
                break;

            case 'delete':
                $id = (int)($_POST['id'] ?? 0);
                try {
                    $stmt = $pdo->prepare("DELETE FROM sessions WHERE id = ?");
                    $stmt->execute([$id]);
                    $success_msg = "Session deleted successfully!";
                } catch (PDOException $e) {
                    $error_msg = "Failed to delete session.";
                    error_log($e->getMessage());
                }
                break;
        }
    }
}

// Fetch all sessions with registration counts and member details
try {
    $stmt = $pdo->prepare("
        SELECT s.*, 
               COUNT(DISTINCT sb.user_id) as registered_members,
               GROUP_CONCAT(DISTINCT u.username ORDER BY u.username ASC SEPARATOR ', ') as member_names
        FROM sessions s
        LEFT JOIN session_bookings sb ON s.id = sb.session_id AND sb.status = 'booked'
        LEFT JOIN users u ON sb.user_id = u.id
        GROUP BY s.id
        ORDER BY s.schedule_day, s.start_time
    ");
    
    if ($stmt->execute()) {
        $sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (empty($sessions)) {
            $info_msg = "No sessions found. Add your first session using the button above.";
        }
    } else {
        throw new PDOException("Failed to execute query");
    }
} catch (PDOException $e) {
    $error_msg = "Failed to fetch sessions. Please try refreshing the page.";
    error_log("Session fetch error: " . $e->getMessage());
    $sessions = [];
}

$days_of_week = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
?>

<?php include '../../partials/header.php'; ?>

<main class="container py-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Session Management</h1>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSessionModal">
            <i class="fas fa-plus"></i> Add New Session
        </button>
    </div>

    <!-- Alert Messages -->
    <?php if ($success_msg): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($success_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($info_msg): ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($info_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Sessions List -->
    <div class="card">
        <div class="card-body">
            <?php if (empty($sessions)): ?>
                <div class="text-center py-4">
                    <p class="mb-0">No sessions available. Click the "Add New Session" button to create one.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Session Name</th>
                                <th>Trainer</th>
                                <th>Day</th>
                                <th>Time</th>
                                <th>Capacity</th>
                                <th>Registered</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sessions as $session): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($session['session_name']); ?></td>
                                    <td><?php echo htmlspecialchars($session['trainer_name']); ?></td>
                                    <td><?php echo htmlspecialchars($session['schedule_day']); ?></td>
                                    <td>
                                        <?php echo date('g:i A', strtotime($session['start_time'])); ?> -
                                        <?php echo date('g:i A', strtotime($session['end_time'])); ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($session['capacity']); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo ($session['registered_members'] >= $session['capacity']) ? 'danger' : 'success'; ?>">
                                            <?php echo (int)$session['registered_members']; ?>/<?php echo $session['capacity']; ?>
                                        </span>
                                        <?php if (!empty($session['member_names'])): ?>
                                            <button type="button" class="btn btn-sm btn-info ms-2" 
                                                    data-bs-toggle="popover" 
                                                    data-bs-trigger="focus"
                                                    data-bs-title="Registered Members"
                                                    data-bs-content="<?php echo htmlspecialchars($session['member_names']); ?>">
                                                View Members
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-warning me-1" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editSessionModal<?php echo $session['id']; ?>">
                                            Edit
                                        </button>
                                        <form method="POST" class="d-inline" 
                                              onsubmit="return confirm('Are you sure you want to delete this session?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id" value="<?php echo $session['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>

                                <!-- Edit Session Modal -->
                                <div class="modal fade" id="editSessionModal<?php echo $session['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Edit Session</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <form method="POST">
                                                <div class="modal-body">
                                                    <input type="hidden" name="action" value="update">
                                                    <input type="hidden" name="id" value="<?php echo $session['id']; ?>">
                                                    
                                                    <div class="mb-3">
                                                        <label for="session_name<?php echo $session['id']; ?>" class="form-label">Session Name</label>
                                                        <input type="text" class="form-control" id="session_name<?php echo $session['id']; ?>" 
                                                               name="session_name" value="<?php echo htmlspecialchars($session['session_name']); ?>" required>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label for="trainer_name<?php echo $session['id']; ?>" class="form-label">Trainer Name</label>
                                                        <input type="text" class="form-control" id="trainer_name<?php echo $session['id']; ?>" 
                                                               name="trainer_name" value="<?php echo htmlspecialchars($session['trainer_name']); ?>" required>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label for="description<?php echo $session['id']; ?>" class="form-label">Description</label>
                                                        <textarea class="form-control" id="description<?php echo $session['id']; ?>" 
                                                                  name="description" rows="3"><?php echo htmlspecialchars($session['description']); ?></textarea>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label for="schedule_day<?php echo $session['id']; ?>" class="form-label">Schedule Day</label>
                                                        <select class="form-select" id="schedule_day<?php echo $session['id']; ?>" name="schedule_day" required>
                                                            <option value="Monday" <?php echo $session['schedule_day'] === 'Monday' ? 'selected' : ''; ?>>Monday</option>
                                                            <option value="Tuesday" <?php echo $session['schedule_day'] === 'Tuesday' ? 'selected' : ''; ?>>Tuesday</option>
                                                            <option value="Wednesday" <?php echo $session['schedule_day'] === 'Wednesday' ? 'selected' : ''; ?>>Wednesday</option>
                                                            <option value="Thursday" <?php echo $session['schedule_day'] === 'Thursday' ? 'selected' : ''; ?>>Thursday</option>
                                                            <option value="Friday" <?php echo $session['schedule_day'] === 'Friday' ? 'selected' : ''; ?>>Friday</option>
                                                            <option value="Saturday" <?php echo $session['schedule_day'] === 'Saturday' ? 'selected' : ''; ?>>Saturday</option>
                                                            <option value="Sunday" <?php echo $session['schedule_day'] === 'Sunday' ? 'selected' : ''; ?>>Sunday</option>
                                                        </select>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <label for="start_time<?php echo $session['id']; ?>" class="form-label">Start Time</label>
                                                            <input type="time" class="form-control" id="start_time<?php echo $session['id']; ?>" 
                                                                   name="start_time" value="<?php echo $session['start_time']; ?>">
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="end_time<?php echo $session['id']; ?>" class="form-label">End Time</label>
                                                            <input type="time" class="form-control" id="end_time<?php echo $session['id']; ?>" 
                                                                   name="end_time" value="<?php echo $session['end_time']; ?>">
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label for="capacity<?php echo $session['id']; ?>" class="form-label">Capacity</label>
                                                        <input type="number" class="form-control" id="capacity<?php echo $session['id']; ?>" 
                                                               name="capacity" value="<?php echo $session['capacity']; ?>" min="1">
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Update Session</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<!-- Add Session Modal -->
<div class="modal fade" id="addSessionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Session</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="session_name" class="form-label">Session Name *</label>
                        <input type="text" class="form-control" id="session_name" name="session_name" required>
                        <div class="invalid-feedback">Please enter a session name.</div>
                    </div>

                    <div class="mb-3">
                        <label for="trainer_name" class="form-label">Trainer Name *</label>
                        <input type="text" class="form-control" id="trainer_name" name="trainer_name" required>
                        <div class="invalid-feedback">Please enter a trainer name.</div>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="schedule_day" class="form-label">Schedule Day *</label>
                        <select class="form-select" id="schedule_day" name="schedule_day" required>
                            <option value="">Select a day</option>
                            <?php foreach ($days_of_week as $day): ?>
                                <option value="<?php echo $day; ?>"><?php echo $day; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Please select a day.</div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="start_time" class="form-label">Start Time *</label>
                            <input type="time" class="form-control" id="start_time" name="start_time" required>
                            <div class="invalid-feedback">Please select a start time.</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="end_time" class="form-label">End Time *</label>
                            <input type="time" class="form-control" id="end_time" name="end_time" required>
                            <div class="invalid-feedback">Please select an end time.</div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="capacity" class="form-label">Capacity *</label>
                        <input type="number" class="form-control" id="capacity" name="capacity" value="10" min="1" required>
                        <div class="invalid-feedback">Please enter a valid capacity (minimum 1).</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Session</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Initialize Popovers -->
<script>
// Form validation
(function () {
    'use strict'
    var forms = document.querySelectorAll('.needs-validation')
    Array.prototype.slice.call(forms).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            form.classList.add('was-validated')
        }, false)
    })

    // Initialize all popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl, {
            html: false,
            sanitize: true
        })
    })
})()
</script>

<?php include '../../partials/footer.php'; ?> 