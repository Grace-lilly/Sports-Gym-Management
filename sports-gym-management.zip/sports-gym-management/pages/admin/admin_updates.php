<?php
require_once '../../config/db_connect.php';
require_once '../../config/auth_check.php';
requireAdmin();

$success_msg = $error_msg = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $title = trim($_POST['title'] ?? '');
                $content = trim($_POST['content'] ?? '');

                if (empty($title) || empty($content)) {
                    $error_msg = "Please provide both title and content.";
                } else {
                    try {
                        $stmt = $pdo->prepare("INSERT INTO updates (title, content, posted_by) VALUES (?, ?, ?)");
                        $stmt->execute([$title, $content, $_SESSION['user_id']]);
                        $success_msg = "Update posted successfully!";
                    } catch (PDOException $e) {
                        $error_msg = "Failed to post update.";
                        error_log($e->getMessage());
                    }
                }
                break;

            case 'delete':
                $update_id = (int)($_POST['update_id'] ?? 0);
                try {
                    $stmt = $pdo->prepare("DELETE FROM updates WHERE update_id = ?");
                    $stmt->execute([$update_id]);
                    $success_msg = "Update deleted successfully!";
                } catch (PDOException $e) {
                    $error_msg = "Failed to delete update.";
                    error_log($e->getMessage());
                }
                break;
        }
    }
}

// Fetch all updates with poster information
try {
    $stmt = $pdo->query("SELECT u.*, CONCAT(us.username) as posted_by_name 
                         FROM updates u 
                         LEFT JOIN users us ON u.posted_by = us.id 
                         ORDER BY u.date_posted DESC");
    $updates = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_msg = "Failed to fetch updates.";
    error_log($e->getMessage());
    $updates = [];
}
?>

<?php include '../../partials/header.php'; ?>

<main class="container py-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Manage Updates</h1>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUpdateModal">
            <i class="fas fa-plus"></i> Post New Update
        </button>
    </div>

    <!-- Alert Messages -->
    <?php if ($success_msg): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($success_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Updates List -->
    <div class="row">
        <?php foreach ($updates as $update): ?>
            <div class="col-12 mb-4">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h5 class="card-title"><?php echo htmlspecialchars($update['title']); ?></h5>
                                <p class="text-muted mb-2">
                                    <small>
                                        <i class="fas fa-user me-1"></i> Posted by: <?php echo htmlspecialchars($update['posted_by_name']); ?>
                                        <i class="fas fa-clock ms-3 me-1"></i> <?php echo date('F d, Y g:i A', strtotime($update['date_posted'])); ?>
                                    </small>
                                </p>
                            </div>
                            <form method="POST" class="ms-3" onsubmit="return confirm('Are you sure you want to delete this update?');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="update_id" value="<?php echo $update['update_id']; ?>">
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                        <div class="card-text mt-3">
                            <?php echo nl2br(htmlspecialchars($update['content'])); ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</main>

<!-- Add Update Modal -->
<div class="modal fade" id="addUpdateModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Post New Update</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="title" class="form-label">Title</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="content" class="form-label">Content</label>
                        <textarea class="form-control" id="content" name="content" rows="5" required></textarea>
                        <div class="form-text">You can use line breaks for formatting.</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Post Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../../partials/footer.php'; ?> 