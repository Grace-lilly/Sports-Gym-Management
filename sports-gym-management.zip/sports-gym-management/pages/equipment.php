<?php
require_once '../config/db_connect.php';
require_once '../config/auth_check.php';

// Fetch all available equipment
try {
    $stmt = $pdo->query("SELECT * FROM equipment WHERE status = 'available' ORDER BY name");
    $equipment = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log($e->getMessage());
    $equipment = [];
}

// Get equipment categories (if any)
try {
    $stmt = $pdo->query("SELECT DISTINCT category FROM equipment WHERE category IS NOT NULL ORDER BY category");
    $categories = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    error_log($e->getMessage());
    $categories = [];
}
?>

<?php include '../partials/header.php'; ?>

<main class="container py-4">
    <h1 class="mb-4">Gym Equipment</h1>

    <!-- Equipment List -->
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <?php foreach ($equipment as $item): ?>
            <div class="col">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($item['name']); ?></h5>
                        <p class="card-text"><?php echo htmlspecialchars($item['description']); ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="badge bg-success">Available</span>
                            <small class="text-muted">
                                Quantity: <?php echo htmlspecialchars($item['quantity']); ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if (empty($equipment)): ?>
        <div class="alert alert-info">
            No equipment is currently available.
        </div>
    <?php endif; ?>
</main>

<?php include '../partials/footer.php'; ?> 