<?php
require_once 'config/db_connect.php';
session_start();

// Fetch latest updates
try {
    $stmt = $pdo->query("SELECT u.*, CONCAT(us.username) as posted_by_name 
                         FROM updates u 
                         LEFT JOIN users us ON u.posted_by = us.id 
                         ORDER BY u.date_posted DESC 
                         LIMIT 3");
    $updates = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log($e->getMessage());
    $updates = [];
}

// Fetch some quick stats
try {
    $stmt = $pdo->query("SELECT 
        (SELECT COUNT(*) FROM users WHERE role = 'user') as member_count,
        (SELECT COUNT(*) FROM sessions) as session_count,
        (SELECT COUNT(*) FROM events WHERE event_date >= CURDATE()) as upcoming_events
    ");
    $stats = $stmt->fetch();
} catch (PDOException $e) {
    error_log($e->getMessage());
    $stats = ['member_count' => 0, 'session_count' => 0, 'upcoming_events' => 0];
}

try {
    // Fetch featured sessions (next 3 upcoming sessions)
    $sessions_stmt = $pdo->prepare("
        SELECT DISTINCT s.*, 
            (s.capacity - COUNT(DISTINCT sb.user_id)) as spots_left
        FROM sessions s
        LEFT JOIN session_bookings sb ON s.id = sb.session_id AND sb.status = 'booked'
        GROUP BY s.id
        ORDER BY FIELD(s.schedule_day, 
            DAYNAME(NOW()), 
            'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
        ), s.start_time
        LIMIT 3
    ");
    $sessions_stmt->execute();
    $featured_sessions = $sessions_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch upcoming events
    $events_stmt = $pdo->prepare("
        SELECT * FROM events 
        WHERE event_date >= CURDATE() 
        ORDER BY event_date ASC 
        LIMIT 3
    ");
    $events_stmt->execute();
    $upcoming_events = $events_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Error fetching home page data: " . $e->getMessage());
}
?>

<?php include 'partials/header.php'; ?>

<!-- Hero Section -->
<div class="hero-section position-relative overflow-hidden p-3 p-md-5 text-center">
    <div class="pattern-overlay"></div>
    <div class="col-md-8 mx-auto my-5 position-relative">
        <h1 class="display-4 fw-bold text-white mb-4">Welcome to Sports Gym</h1>
        <p class="lead mb-4 text-white">Transform your life with our state-of-the-art facilities, expert trainers, and diverse fitness programs.</p>
        <?php if (!isset($_SESSION['user_id'])): ?>
            <div class="d-grid gap-2 d-sm-flex justify-content-sm-center mb-5">
                <a href="pages/register.php" class="btn btn-primary btn-lg px-4 me-sm-3 hero-btn">Join Now</a>
                <a href="pages/login.php" class="btn btn-outline-light btn-lg px-4 hero-btn">Sign In</a>
            </div>
        <?php else: ?>
            <a href="pages/sessions.php" class="btn btn-primary btn-lg px-4 hero-btn">Book a Session</a>
        <?php endif; ?>
    </div>
</div>

<!-- Features Section -->
<div class="container px-4 py-5">
    <div class="row g-4 py-5 row-cols-1 row-cols-lg-3">
        <div class="col d-flex align-items-start">
            <div class="icon-square text-bg-light d-inline-flex align-items-center justify-content-center fs-4 flex-shrink-0 me-3">
                <i class="fas fa-dumbbell"></i>
            </div>
            <div>
                <h3 class="fs-2">Modern Equipment</h3>
                <p>Access to state-of-the-art fitness equipment and facilities to help you achieve your fitness goals.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start">
            <div class="icon-square text-bg-light d-inline-flex align-items-center justify-content-center fs-4 flex-shrink-0 me-3">
                <i class="fas fa-user-friends"></i>
            </div>
            <div>
                <h3 class="fs-2">Expert Trainers</h3>
                <p>Work with certified professional trainers who will guide you through your fitness journey.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start">
            <div class="icon-square text-bg-light d-inline-flex align-items-center justify-content-center fs-4 flex-shrink-0 me-3">
                <i class="fas fa-calendar-check"></i>
            </div>
            <div>
                <h3 class="fs-2">Flexible Sessions</h3>
                <p>Choose from various training sessions that fit your schedule and fitness level.</p>
            </div>
        </div>
    </div>
</div>

<!-- Featured Sessions Section -->
<div class="container px-4 py-5">
    <h2 class="pb-2 border-bottom">Featured Sessions</h2>
    <div class="row row-cols-1 row-cols-md-3 g-4 py-5">
        <?php foreach ($featured_sessions as $session): ?>
            <div class="col">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($session['session_name']); ?></h5>
                        <p class="card-text">
                            <i class="fas fa-user-tie me-2"></i><?php echo htmlspecialchars($session['trainer_name']); ?><br>
                            <i class="fas fa-calendar me-2"></i><?php echo htmlspecialchars($session['schedule_day']); ?><br>
                            <i class="fas fa-clock me-2"></i><?php echo date('g:i A', strtotime($session['start_time'])) . ' - ' . 
                                                                   date('g:i A', strtotime($session['end_time'])); ?>
                        </p>
                        <?php if ($session['spots_left'] > 0): ?>
                            <p class="text-success">
                                <i class="fas fa-user-check me-2"></i><?php echo $session['spots_left']; ?> spots available
                            </p>
                        <?php else: ?>
                            <p class="text-danger">
                                <i class="fas fa-user-times me-2"></i>Session Full
                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer bg-transparent border-top-0">
                        <a href="pages/sessions.php" class="btn btn-primary w-100">Book Now</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Upcoming Events Section -->
<div class="container px-4 py-5">
    <h2 class="pb-2 border-bottom">Upcoming Events</h2>
    <div class="row row-cols-1 row-cols-md-3 g-4 py-5">
        <?php foreach ($upcoming_events as $event): ?>
            <div class="col">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($event['title']); ?></h5>
                        <p class="card-text">
                            <i class="fas fa-calendar-day me-2"></i><?php echo date('F j, Y', strtotime($event['event_date'])); ?><br>
                            <i class="fas fa-clock me-2"></i><?php echo date('g:i A', strtotime($event['start_time'])) . ' - ' . 
                                                                   date('g:i A', strtotime($event['end_time'])); ?><br>
                            <i class="fas fa-map-marker-alt me-2"></i><?php echo htmlspecialchars($event['location']); ?>
                        </p>
                        <p class="card-text"><?php echo htmlspecialchars(substr($event['description'], 0, 100)) . '...'; ?></p>
                    </div>
                    <div class="card-footer bg-transparent border-top-0">
                        <a href="pages/events.php" class="btn btn-outline-primary w-100">Learn More</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Call to Action Section -->
<div class="container px-4 py-5">
    <div class="p-5 mb-4 bg-light rounded-3">
        <div class="container-fluid py-5">
            <h2 class="display-5 fw-bold">Start Your Fitness Journey Today</h2>
            <p class="col-md-8 fs-4">Join our community of fitness enthusiasts and transform your life with our expert guidance and support.</p>
            <a href="<?php echo isset($_SESSION['user_id']) ? 'pages/sessions.php' : 'pages/register.php'; ?>" 
               class="btn btn-primary btn-lg">
                <?php echo isset($_SESSION['user_id']) ? 'Book a Session' : 'Get Started'; ?>
            </a>
        </div>
    </div>
</div>

<!-- Custom CSS -->
<style>
.hero-section {
    background: linear-gradient(135deg, #000428, #004e92);
    min-height: 600px;
    display: flex;
    align-items: center;
    position: relative;
    overflow: hidden;
}

.pattern-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-image: 
        linear-gradient(45deg, rgba(255,255,255,0.1) 25%, transparent 25%),
        linear-gradient(-45deg, rgba(255,255,255,0.1) 25%, transparent 25%),
        linear-gradient(45deg, transparent 75%, rgba(255,255,255,0.1) 75%),
        linear-gradient(-45deg, transparent 75%, rgba(255,255,255,0.1) 75%);
    background-size: 20px 20px;
    background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
    animation: pattern-move 20s linear infinite;
}

.hero-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: 
        radial-gradient(circle at 20% 30%, rgba(0, 78, 146, 0.8) 0%, transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(0, 4, 40, 0.8) 0%, transparent 50%);
    z-index: 1;
}

.hero-section::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(0deg, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.3) 100%);
    z-index: 2;
}

.hero-section .col-md-8 {
    z-index: 3;
}

.hero-btn {
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
    z-index: 1;
}

.hero-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
        120deg,
        transparent,
        rgba(255, 255, 255, 0.2),
        transparent
    );
    transition: all 0.5s;
    z-index: -1;
}

.hero-btn:hover::before {
    left: 100%;
}

@keyframes pattern-move {
    0% {
        background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
    }
    100% {
        background-position: 40px 40px, 40px 50px, 50px 30px, 30px 40px;
    }
}

.display-4 {
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    font-weight: 800;
    letter-spacing: -0.5px;
}

.lead {
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
    font-weight: 400;
    letter-spacing: 0.2px;
}

@media (max-width: 768px) {
    .hero-section {
        min-height: 500px;
    }
    .display-4 {
        font-size: 2.5rem;
    }
    .lead {
        font-size: 1.1rem;
    }
}

.icon-square {
    width: 48px;
    height: 48px;
    border-radius: 0.75rem;
}

.card {
    transition: transform 0.2s;
}

.card:hover {
    transform: translateY(-5px);
}
</style>

<?php include 'partials/footer.php'; ?> 