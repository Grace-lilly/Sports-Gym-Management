<?php
require_once 'db_connect.php';

try {
    // Admin credentials
    $username = 'adminuser';
    $email = 'admin@sportsgym.com';
    $password = 'admin'; // This will be hashed
    $role = 'admin';

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Check if admin already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    
    if ($stmt->rowCount() > 0) {
        echo "Admin user already exists!";
    } else {
        // Create admin user
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->execute([$username, $email, $hashedPassword, $role]);
        echo "Admin user created successfully!";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

// For security, delete this file after running it
// unlink(__FILE__); 