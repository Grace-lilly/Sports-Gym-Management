-- Drop existing tables if they exist (to avoid conflicts)
DROP TABLE IF EXISTS `session_bookings`;
DROP TABLE IF EXISTS `sessions`;

-- Create the sessions table with correct structure
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_name` varchar(100) NOT NULL,
  `trainer_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `schedule_day` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT 10,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create the session_bookings table
CREATE TABLE `session_bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `booking_date` date NOT NULL,
  `status` enum('booked','cancelled','attended') NOT NULL DEFAULT 'booked',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_booking` (`session_id`,`user_id`,`booking_date`),
  FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert some test data
INSERT INTO `sessions` (`session_name`, `trainer_name`, `description`, `schedule_day`, `start_time`, `end_time`, `capacity`) VALUES
('Morning Yoga', 'John Smith', 'Start your day with energizing yoga poses', 'Monday', '07:00:00', '08:00:00', 15),
('Weight Training', 'Sarah Johnson', 'Build strength and muscle with guided weight training', 'Monday', '09:00:00', '10:30:00', 10),
('Evening Cardio', 'Mike Wilson', 'High-intensity cardio workout', 'Tuesday', '18:00:00', '19:00:00', 20); 